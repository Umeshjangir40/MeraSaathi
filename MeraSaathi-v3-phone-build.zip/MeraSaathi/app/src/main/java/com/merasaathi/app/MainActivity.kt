package com.merasaathi.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private val client = OkHttpClient()
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText
    private lateinit var send: TextView
    private lateinit var webToggle: CheckBox
    private lateinit var scroll: ScrollView
    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private var sessionId = ""
    private val prefs by lazy { getSharedPreferences("merasaathi", Context.MODE_PRIVATE) }
    private val backendUrl = BuildConfig.MERASAATHI_BACKEND_URL
    private val bg = Color.rgb(250, 247, 244)
    private val ink = Color.rgb(42, 36, 34)
    private val accent = Color.rgb(111, 72, 62)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sessionId = prefs.getString("session_id", null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("session_id", it).apply() }
        tts = TextToSpeech(this, this)
        buildUi(); restoreHistory()
        if (messages.childCount == 0) addBubble("Namaste ❤️\nMain MeraSaathi hoon — tera personal AI saathi. Bol ya type kar, main yahin hoon.", false)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply { setPadding(20, 20, 14, 10); gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply { text = "MeraSaathi\nTera AI, Tera Saathi"; textSize = 21f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) }
        webToggle = CheckBox(this).apply { text = "🌐"; textSize = 18f; buttonTintList = android.content.res.ColorStateList.valueOf(accent); contentDescription = "Web search"; setOnCheckedChangeListener { _, checked -> Toast.makeText(this@MainActivity, if (checked) "Web search ON" else "Web search OFF", Toast.LENGTH_SHORT).show() } }
        val clear = TextView(this).apply { text = "↻"; textSize = 28f; setTextColor(accent); gravity = Gravity.CENTER; setOnClickListener { clearChat() } }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f)); header.addView(webToggle, LinearLayout.LayoutParams(55, 55)); header.addView(clear, LinearLayout.LayoutParams(48, 55))

        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 8, 14, 12) }
        scroll = ScrollView(this).apply { addView(messages); layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }

        val bar = LinearLayout(this).apply { setPadding(12, 8, 12, 16); gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply { hint = "MeraSaathi se kuch pooch..."; textSize = 16f; maxLines = 4; setPadding(18, 12, 18, 12); setBackgroundColor(Color.WHITE) }
        val mic = TextView(this).apply { text = "🎙"; textSize = 22f; gravity = Gravity.CENTER; setOnClickListener { startVoiceInput() } }
        send = TextView(this).apply { text = "➤"; textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setBackgroundColor(accent); setOnClickListener { sendMessage() } }
        bar.addView(input, LinearLayout.LayoutParams(0, 56, 1f)); bar.addView(mic, LinearLayout.LayoutParams(52, 56)); bar.addView(send, LinearLayout.LayoutParams(56, 56))
        root.addView(header); root.addView(scroll); root.addView(bar); setContentView(root)
    }

    private fun addBubble(text: String, mine: Boolean) {
        val card = TextView(this).apply { this.text = text; textSize = 16f; setTextColor(ink); setPadding(18, 14, 18, 14); setBackgroundColor(if (mine) Color.rgb(239, 222, 214) else Color.WHITE) }
        val p = LinearLayout.LayoutParams(-2, -2).apply { setMargins(if (mine) 70 else 4, 7, if (mine) 4 else 70, 7); gravity = if (mine) Gravity.END else Gravity.START }
        messages.addView(card, p); scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun saveMessage(text: String, mine: Boolean) {
        val old = prefs.getString("history", "") ?: ""; val row = JSONObject().put("text", text).put("mine", mine)
        prefs.edit().putString("history", if (old.isEmpty()) row.toString() else "$old\n$row").apply()
    }
    private fun restoreHistory() { (prefs.getString("history", "") ?: "").lines().filter { it.isNotBlank() }.takeLast(100).forEach { runCatching { JSONObject(it).let { j -> addBubble(j.optString("text"), j.optBoolean("mine")) } } } }

    private fun clearChat() {
        lifecycleScope.launch(Dispatchers.IO) { runCatching { postJson("/reset", JSONObject().put("sessionId", sessionId)) } }
        sessionId = UUID.randomUUID().toString(); prefs.edit().putString("session_id", sessionId).remove("history").apply(); messages.removeAllViews(); addBubble("Chat reset ❤️ Ab nayi conversation start karte hain.", false)
    }

    private fun sendMessage() {
        val text = input.text.toString().trim(); if (text.isEmpty()) return
        input.text.clear(); addBubble(text, true); saveMessage(text, true); send.isEnabled = false
        lifecycleScope.launch {
            val reply = withContext(Dispatchers.IO) { try { val body = JSONObject().put("message", text).put("sessionId", sessionId).put("webSearch", webToggle.isChecked); JSONObject(postJson("/chat", body)).optString("reply", "Abhi response nahi aa paaya.") } catch (_: Exception) { "Backend connect nahi ho paaya. Server start karke dobara try kar bhai ❤️" } }
            addBubble(reply, false); saveMessage(reply, false); speak(reply); send.isEnabled = true
        }
    }

    private fun postJson(path: String, json: JSONObject): String {
        val req = Request.Builder().url(backendUrl + path).post(json.toString().toRequestBody("application/json".toMediaType())).build()
        return client.newCall(req).execute().use { it.body?.string() ?: "{}" }
    }

    private fun startVoiceInput() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 42); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { Toast.makeText(this, "Phone me speech recognition available nahi hai.", Toast.LENGTH_SHORT).show(); return }
        speechRecognizer?.destroy(); speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle) { input.setText(results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""); input.setSelection(input.length()) }
                override fun onError(error: Int) { Toast.makeText(this@MainActivity, "Voice samajh nahi aayi, dobara bol bhai ❤️", Toast.LENGTH_SHORT).show() }
                override fun onReadyForSpeech(p0: Bundle?) { Toast.makeText(this@MainActivity, "Sun raha hoon… 🎙️", Toast.LENGTH_SHORT).show() }
                override fun onBeginningOfSpeech() {} override fun onRmsChanged(p0: Float) {} override fun onBufferReceived(p0: ByteArray?) {}
                override fun onEndOfSpeech() {} override fun onPartialResults(p0: Bundle?) {} override fun onEvent(p0: Int, p1: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag()) })
        }
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN") }
    private fun speak(text: String) { if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "merasaathi-reply") }
    override fun onDestroy() { speechRecognizer?.destroy(); if (::tts.isInitialized) tts.shutdown(); super.onDestroy() }
}
