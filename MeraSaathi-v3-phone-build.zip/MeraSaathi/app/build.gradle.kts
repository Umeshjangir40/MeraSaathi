plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.merasaathi.app"
    compileSdk = 35
    buildFeatures { buildConfig = true }
    defaultConfig {
        applicationId = "com.merasaathi.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
        val backendUrl = (project.findProperty("MERASAATHI_BACKEND_URL") as String?) ?: "http://10.0.2.2:3000"
        buildConfigField("String", "MERASAATHI_BACKEND_URL", "\"$backendUrl\"")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
