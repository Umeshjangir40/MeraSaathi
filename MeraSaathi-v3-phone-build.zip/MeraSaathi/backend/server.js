import 'dotenv/config';
import express from 'express';
import OpenAI from 'openai';
import fs from 'node:fs/promises';
import path from 'node:path';

const app = express();
app.use(express.json({ limit: '1mb' }));
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const model = process.env.OPENAI_MODEL || 'gpt-6-luna';
const memoryFile = path.join(process.cwd(), 'data', 'sessions.json');

async function loadSessions() {
  try { return JSON.parse(await fs.readFile(memoryFile, 'utf8')); }
  catch { return {}; }
}
async function saveSessions(sessions) {
  await fs.mkdir(path.dirname(memoryFile), { recursive: true });
  await fs.writeFile(memoryFile, JSON.stringify(sessions, null, 2));
}

const sessions = await loadSessions();
const baseInstructions = `You are MeraSaathi, a warm, friendly personal AI companion. Reply naturally in the user's language, often Hinglish/Hindi when they use it. Be concise, helpful and respectful. Remember useful context from the ongoing conversation and use it naturally. Never claim to remember something that is not in the conversation.`;

app.get('/health', (_req, res) => res.json({ ok: true, model }));

app.post('/chat', async (req, res) => {
  try {
    const message = String(req.body?.message || '').trim();
    const sessionId = String(req.body?.sessionId || '').trim();
    const webSearch = Boolean(req.body?.webSearch);
    if (!message || !sessionId) return res.status(400).json({ error: 'message and sessionId required' });

    let conversationId = sessions[sessionId];
    if (!conversationId) {
      const conversation = await openai.conversations.create();
      conversationId = conversation.id;
      sessions[sessionId] = conversationId;
      await saveSessions(sessions);
    }

    const params = {
      model,
      instructions: baseInstructions,
      input: [{ role: 'user', content: message }],
      conversation: conversationId,
    };
    if (webSearch) params.tools = [{ type: 'web_search_preview' }];

    const response = await openai.responses.create(params);
    res.json({ reply: response.output_text, conversationId });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'AI request failed' });
  }
});

app.post('/reset', async (req, res) => {
  const sessionId = String(req.body?.sessionId || '').trim();
  if (sessionId) { delete sessions[sessionId]; await saveSessions(sessions); }
  res.json({ ok: true });
});

app.listen(process.env.PORT || 3000, () => console.log(`MeraSaathi backend running on ${process.env.PORT || 3000}`));
