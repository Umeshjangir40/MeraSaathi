# MeraSaathi v2 — Tera AI, Tera Saathi

A native Android starter app with an OpenAI backend.

## Included
- OpenAI Responses API chat
- Server-side conversation memory using the Conversations API
- Optional built-in web search toggle
- Android speech-to-text mic input
- Android text-to-speech replies
- Local chat history
- Reset conversation
- API key stays on the backend
- Emulator backend URL: `http://10.0.2.2:3000`

OpenAI's current guidance uses Responses + Conversations for new integrations; the old Assistants API was sunset on August 26, 2026.

## 1) Backend
```bash
cd backend
npm install
cp .env.example .env
# Put your OpenAI API key in .env
npm start
```

For a physical phone, change `backendUrl` in `MainActivity.kt` from `10.0.2.2` to the computer's LAN IP and keep the phone/computer on the same network. Production should use HTTPS.

## 2) Android
Open the `MeraSaathi` folder in Android Studio and run the `app` configuration on an emulator or Android phone. The mic permission is requested the first time voice input is used.

## 3) Web search
Turn on the 🌐 switch in the header before sending a question that needs current web information. This uses the OpenAI Responses web-search tool and can add tool/search charges.

## 4) APK
Use Android Studio: **Build > Build APK(s)**. The debug APK will normally appear under `app/build/outputs/apk/debug/`.

## 📱 Phone-only APK build (GitHub Actions)

1. Phone browser se GitHub par new repository banao, e.g. `MeraSaathi`.
2. Is ZIP ko extract karke repository me files upload karo.
3. Repository → **Settings → Secrets and variables → Actions → New repository secret**.
4. Secret name: `MERASAATHI_BACKEND_URL` and value: tumhare deployed backend ka HTTPS URL, e.g. `https://merasaathi-backend.onrender.com`.
5. `Actions` tab → **Build MeraSaathi APK** → **Run workflow**.
6. Build complete hone par workflow ke **Artifacts** me `MeraSaathi-debug-apk` download karo aur Android phone par install karo.

### Backend phone-only deployment

The included `render.yaml` is ready for a Render Node web service. Create a Render service from this repository, set `OPENAI_API_KEY` as a secret, deploy it, then put the resulting HTTPS URL into the GitHub Actions secret above.

> Never put the OpenAI API key in the Android app or GitHub source code. Keep it only as the backend's secret environment variable.
